package org.mazeApp;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import org.mazeApp.model.Graph;
import org.mazeApp.view.GraphView;
import org.mazeApp.view.MazeView;

public class Main extends Application {

    public GraphView graphView;
    public MazeView mazeView;
    public Graph graph;  // Cette variable doit être unique

    @Override
    public void start(Stage primaryStage) {
        // Créer un labyrinthe 5x5
        this.graph = new Graph(42, 5);  // Utiliser this.graph
        this.graphView = new GraphView();
        this.mazeView = new MazeView();
        this.graphView.draw(this.graph); 
        this.mazeView.draw(this.graph);   
        // Créer des conteneurs pour chaque vue avec des titres
        VBox graphContainer = new VBox(10);
        VBox mazeContainer = new VBox(10);
        
        Label graphLabel = new Label("Vue du Graphe");
        Label mazeLabel = new Label("Vue du Labyrinthe");
        graphContainer.getChildren().addAll(graphLabel, this.graphView);  // Utiliser this.graphView
        mazeContainer.getChildren().addAll(mazeLabel, this.mazeView);    // Utiliser this.mazeView
        // Conteneur horizontal pour mettre les vues côte à côte
        HBox root = new HBox(20);
        root.getChildren().addAll(graphContainer, mazeContainer);
        
        // Ajouter un peu de style
        root.setStyle("-fx-padding: 10;");
        graphLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 14;");
        mazeLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 14;");
        // Créer un bouton pour effacer le graphe
        Button clearButton = new Button("Effacer");
        Button generateButton = new Button("Regenerer");
        generateButton.setOnAction(e -> {
            System.out.println("Regenerer le graphe");
            this.graph = new Graph((int) (Math.random() * Integer.MAX_VALUE), 10);  // Regénérer le graphe avec une seed aléatoire et une taille fixe de 5x5
            refresh_view();
        });
        clearButton.setOnAction(e -> {
            System.out.println("Effacer le graphe");
            this.graph.clearGraph();
            refresh_view();
        });
        // Ajouter le bouton au conteneur du graphe
        graphContainer.getChildren().addAll(clearButton, generateButton);
        
        Scene scene = new Scene(root, 1200, 600);
        primaryStage.setTitle("Maze Visualization");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
    public void refresh_view() {
        this.graphView.draw(this.graph);
        this.mazeView.draw(this.graph);    
    }
}