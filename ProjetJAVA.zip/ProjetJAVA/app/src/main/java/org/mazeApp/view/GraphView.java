package org.mazeApp.view;

import javafx.scene.layout.Pane;
import javafx.scene.shape.Line;
import javafx.scene.shape.Circle;
import org.mazeApp.model.Graph;
import org.mazeApp.model.Edges;
import java.util.ArrayList;

public class GraphView extends Pane {

    private double cellSize = 50;
    private double padding = 20;
    
    public void draw(Graph graph) {
        // Effacer tous les éléments existants avant de redessiner
        getChildren().clear();
        
        // Calculer la taille du graphe
        int size = (int) Math.sqrt(graph.getGraphMaze().size());
        
        // Dessiner les sommets
        for (int i = 0; i < graph.getGraphMaze().size(); i++) {
            double x = (i % size) * cellSize + padding;
            double y = (i / size) * cellSize + padding;
            
            Circle vertex = new Circle(x, y, 5);
            vertex.setStyle("-fx-fill: white; -fx-stroke: black;");
            getChildren().add(vertex);
            
            // Dessiner les arêtes
            ArrayList<Edges> edges = graph.getGraphMaze().get(i);
            for (Edges edge : edges) {
                int destIndex = edge.getDestination();
                double destX = (destIndex % size) * cellSize + padding;
                double destY = (destIndex / size) * cellSize + padding;
                
                Line line = new Line(x, y, destX, destY);
                getChildren().add(line);
            }
        }
    }
}
